﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AboutBoxAcercaDe
   Inherits System.Windows.Forms.Form

   'Form reemplaza a Dispose para limpiar la lista de componentes.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   Friend WithEvents TableLayoutPanel As System.Windows.Forms.TableLayoutPanel
   Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
   Friend WithEvents LabelProductName As System.Windows.Forms.Label
   Friend WithEvents LabelVersion As System.Windows.Forms.Label
   Friend WithEvents TextBoxDescription As System.Windows.Forms.TextBox
   Friend WithEvents OKButton As System.Windows.Forms.Button
   Friend WithEvents LabelCopyright As System.Windows.Forms.Label

   'Requerido por el Diseñador de Windows Forms
   Private components As System.ComponentModel.IContainer

   'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
   'Se puede modificar usando el Diseñador de Windows Forms.  
   'No lo modifique con el editor de código.
   <System.Diagnostics.DebuggerStepThrough()>
   Private Sub InitializeComponent()
      Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AboutBoxAcercaDe))
      Me.TableLayoutPanel = New System.Windows.Forms.TableLayoutPanel()
      Me.TextBox1 = New System.Windows.Forms.TextBox()
      Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
      Me.LabelProductName = New System.Windows.Forms.Label()
      Me.LabelVersion = New System.Windows.Forms.Label()
      Me.LabelCopyright = New System.Windows.Forms.Label()
      Me.TextBoxDescription = New System.Windows.Forms.TextBox()
      Me.OKButton = New System.Windows.Forms.Button()
      Me.labelEmail = New System.Windows.Forms.Label()
      Me.TableLayoutPanel.SuspendLayout()
      CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'TableLayoutPanel
      '
      Me.TableLayoutPanel.ColumnCount = 2
      Me.TableLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.97495!))
      Me.TableLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.02505!))
      Me.TableLayoutPanel.Controls.Add(Me.TextBox1, 1, 4)
      Me.TableLayoutPanel.Controls.Add(Me.LogoPictureBox, 0, 0)
      Me.TableLayoutPanel.Controls.Add(Me.LabelProductName, 1, 0)
      Me.TableLayoutPanel.Controls.Add(Me.LabelVersion, 1, 1)
      Me.TableLayoutPanel.Controls.Add(Me.LabelCopyright, 1, 2)
      Me.TableLayoutPanel.Controls.Add(Me.TextBoxDescription, 1, 5)
      Me.TableLayoutPanel.Controls.Add(Me.OKButton, 1, 6)
      Me.TableLayoutPanel.Controls.Add(Me.labelEmail, 1, 3)
      Me.TableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill
      Me.TableLayoutPanel.Location = New System.Drawing.Point(9, 9)
      Me.TableLayoutPanel.Name = "TableLayoutPanel"
      Me.TableLayoutPanel.RowCount = 7
      Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.0!))
      Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.0!))
      Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.0!))
      Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.0!))
      Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
      Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.0!))
      Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
      Me.TableLayoutPanel.Size = New System.Drawing.Size(489, 275)
      Me.TableLayoutPanel.TabIndex = 0
      '
      'TextBox1
      '
      Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill
      Me.TextBox1.Location = New System.Drawing.Point(142, 91)
      Me.TextBox1.Margin = New System.Windows.Forms.Padding(6, 3, 3, 3)
      Me.TextBox1.Multiline = True
      Me.TextBox1.Name = "TextBox1"
      Me.TextBox1.ReadOnly = True
      Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
      Me.TextBox1.Size = New System.Drawing.Size(344, 131)
      Me.TextBox1.TabIndex = 1
      Me.TextBox1.TabStop = False
      Me.TextBox1.Text = resources.GetString("TextBox1.Text")
      '
      'LogoPictureBox
      '
      Me.LogoPictureBox.Dock = System.Windows.Forms.DockStyle.Fill
      Me.LogoPictureBox.ErrorImage = Nothing
      Me.LogoPictureBox.Image = CType(resources.GetObject("LogoPictureBox.Image"), System.Drawing.Image)
      Me.LogoPictureBox.InitialImage = Nothing
      Me.LogoPictureBox.Location = New System.Drawing.Point(3, 3)
      Me.LogoPictureBox.Name = "LogoPictureBox"
      Me.TableLayoutPanel.SetRowSpan(Me.LogoPictureBox, 7)
      Me.LogoPictureBox.Size = New System.Drawing.Size(130, 269)
      Me.LogoPictureBox.TabIndex = 0
      Me.LogoPictureBox.TabStop = False
      '
      'LabelProductName
      '
      Me.LabelProductName.Dock = System.Windows.Forms.DockStyle.Fill
      Me.LabelProductName.Location = New System.Drawing.Point(142, 0)
      Me.LabelProductName.Margin = New System.Windows.Forms.Padding(6, 0, 3, 0)
      Me.LabelProductName.MaximumSize = New System.Drawing.Size(0, 17)
      Me.LabelProductName.Name = "LabelProductName"
      Me.LabelProductName.Size = New System.Drawing.Size(344, 17)
      Me.LabelProductName.TabIndex = 0
      Me.LabelProductName.Text = "SynchronizeFLDR "
      Me.LabelProductName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
      '
      'LabelVersion
      '
      Me.LabelVersion.Dock = System.Windows.Forms.DockStyle.Fill
      Me.LabelVersion.Location = New System.Drawing.Point(142, 22)
      Me.LabelVersion.Margin = New System.Windows.Forms.Padding(6, 0, 3, 0)
      Me.LabelVersion.MaximumSize = New System.Drawing.Size(0, 17)
      Me.LabelVersion.Name = "LabelVersion"
      Me.LabelVersion.Size = New System.Drawing.Size(344, 17)
      Me.LabelVersion.TabIndex = 0
      Me.LabelVersion.Text = "Versión  1.00"
      Me.LabelVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
      '
      'LabelCopyright
      '
      Me.LabelCopyright.Dock = System.Windows.Forms.DockStyle.Fill
      Me.LabelCopyright.Location = New System.Drawing.Point(142, 44)
      Me.LabelCopyright.Margin = New System.Windows.Forms.Padding(6, 0, 3, 0)
      Me.LabelCopyright.MaximumSize = New System.Drawing.Size(0, 17)
      Me.LabelCopyright.Name = "LabelCopyright"
      Me.LabelCopyright.Size = New System.Drawing.Size(344, 17)
      Me.LabelCopyright.TabIndex = 0
      Me.LabelCopyright.Text = "SynchronizeFLDR Copyright (C) 2016 Juanra Goti, ubaloie"
      Me.LabelCopyright.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
      '
      'TextBoxDescription
      '
      Me.TextBoxDescription.Dock = System.Windows.Forms.DockStyle.Fill
      Me.TextBoxDescription.Location = New System.Drawing.Point(142, 228)
      Me.TextBoxDescription.Margin = New System.Windows.Forms.Padding(6, 3, 3, 3)
      Me.TextBoxDescription.Name = "TextBoxDescription"
      Me.TextBoxDescription.ReadOnly = True
      Me.TextBoxDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both
      Me.TextBoxDescription.Size = New System.Drawing.Size(344, 20)
      Me.TextBoxDescription.TabIndex = 0
      Me.TextBoxDescription.TabStop = False
      '
      'OKButton
      '
      Me.OKButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.OKButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.OKButton.Location = New System.Drawing.Point(411, 250)
      Me.OKButton.Name = "OKButton"
      Me.OKButton.Size = New System.Drawing.Size(75, 22)
      Me.OKButton.TabIndex = 0
      Me.OKButton.Text = "&Aceptar"
      '
      'labelEmail
      '
      Me.labelEmail.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.labelEmail.AutoSize = True
      Me.labelEmail.Location = New System.Drawing.Point(142, 70)
      Me.labelEmail.Margin = New System.Windows.Forms.Padding(6, 0, 3, 0)
      Me.labelEmail.Name = "labelEmail"
      Me.labelEmail.Size = New System.Drawing.Size(344, 13)
      Me.labelEmail.TabIndex = 2
      Me.labelEmail.Text = "ubaloie@hotmail.com"
      '
      'AboutBoxAcercaDe
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.CancelButton = Me.OKButton
      Me.ClientSize = New System.Drawing.Size(507, 293)
      Me.Controls.Add(Me.TableLayoutPanel)
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "AboutBoxAcercaDe"
      Me.Padding = New System.Windows.Forms.Padding(9)
      Me.ShowInTaskbar = False
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "AboutBoxAcercaDe"
      Me.TableLayoutPanel.ResumeLayout(False)
      Me.TableLayoutPanel.PerformLayout()
      CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)

   End Sub

   Friend WithEvents TextBox1 As TextBox
   Friend WithEvents labelEmail As Label
End Class
