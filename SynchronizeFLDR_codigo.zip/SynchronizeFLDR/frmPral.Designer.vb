﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPral
   Inherits System.Windows.Forms.Form

   'Form reemplaza a Dispose para limpiar la lista de componentes.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Requerido por el Diseñador de Windows Forms
   Private components As System.ComponentModel.IContainer

   'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
   'Se puede modificar usando el Diseñador de Windows Forms.  
   'No lo modifique con el editor de código.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
      Me.GroupBoxCarpetas = New System.Windows.Forms.GroupBox()
      Me.GroupBoxBotones = New System.Windows.Forms.GroupBox()
      Me.ButtonSalir = New System.Windows.Forms.Button()
      Me.ButtonSincronizarCarpetas = New System.Windows.Forms.Button()
      Me.ButtonAcercaDe = New System.Windows.Forms.Button()
      Me.ButtonCarpetaOrigen = New System.Windows.Forms.Button()
      Me.ButtonCarpetaDestino = New System.Windows.Forms.Button()
      Me.TextBoxCarpetaOrigen = New System.Windows.Forms.TextBox()
      Me.TextBoxCarpetaDestino = New System.Windows.Forms.TextBox()
      Me.GroupBoxCarpetas.SuspendLayout()
      Me.GroupBoxBotones.SuspendLayout()
      Me.SuspendLayout()
      '
      'GroupBoxCarpetas
      '
      Me.GroupBoxCarpetas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.GroupBoxCarpetas.Controls.Add(Me.TextBoxCarpetaDestino)
      Me.GroupBoxCarpetas.Controls.Add(Me.TextBoxCarpetaOrigen)
      Me.GroupBoxCarpetas.Controls.Add(Me.ButtonCarpetaDestino)
      Me.GroupBoxCarpetas.Controls.Add(Me.ButtonCarpetaOrigen)
      Me.GroupBoxCarpetas.Location = New System.Drawing.Point(12, 12)
      Me.GroupBoxCarpetas.Name = "GroupBoxCarpetas"
      Me.GroupBoxCarpetas.Size = New System.Drawing.Size(709, 100)
      Me.GroupBoxCarpetas.TabIndex = 0
      Me.GroupBoxCarpetas.TabStop = False
      Me.GroupBoxCarpetas.Text = "Carpetas:"
      '
      'GroupBoxBotones
      '
      Me.GroupBoxBotones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.GroupBoxBotones.Controls.Add(Me.ButtonAcercaDe)
      Me.GroupBoxBotones.Controls.Add(Me.ButtonSincronizarCarpetas)
      Me.GroupBoxBotones.Controls.Add(Me.ButtonSalir)
      Me.GroupBoxBotones.Location = New System.Drawing.Point(12, 118)
      Me.GroupBoxBotones.Name = "GroupBoxBotones"
      Me.GroupBoxBotones.Size = New System.Drawing.Size(709, 59)
      Me.GroupBoxBotones.TabIndex = 2
      Me.GroupBoxBotones.TabStop = False
      '
      'ButtonSalir
      '
      Me.ButtonSalir.Location = New System.Drawing.Point(20, 20)
      Me.ButtonSalir.Name = "ButtonSalir"
      Me.ButtonSalir.Size = New System.Drawing.Size(98, 23)
      Me.ButtonSalir.TabIndex = 0
      Me.ButtonSalir.Text = "Salir"
      Me.ButtonSalir.UseVisualStyleBackColor = True
      '
      'ButtonSincronizarCarpetas
      '
      Me.ButtonSincronizarCarpetas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
      Me.ButtonSincronizarCarpetas.Location = New System.Drawing.Point(306, 20)
      Me.ButtonSincronizarCarpetas.Name = "ButtonSincronizarCarpetas"
      Me.ButtonSincronizarCarpetas.Size = New System.Drawing.Size(95, 23)
      Me.ButtonSincronizarCarpetas.TabIndex = 1
      Me.ButtonSincronizarCarpetas.Text = "Sincronizar carpetas"
      Me.ButtonSincronizarCarpetas.UseVisualStyleBackColor = True
      '
      'ButtonAcercaDe
      '
      Me.ButtonAcercaDe.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.ButtonAcercaDe.Location = New System.Drawing.Point(588, 20)
      Me.ButtonAcercaDe.Name = "ButtonAcercaDe"
      Me.ButtonAcercaDe.Size = New System.Drawing.Size(94, 23)
      Me.ButtonAcercaDe.TabIndex = 2
      Me.ButtonAcercaDe.Text = "Acerca de..."
      Me.ButtonAcercaDe.UseVisualStyleBackColor = True
      '
      'ButtonCarpetaOrigen
      '
      Me.ButtonCarpetaOrigen.Location = New System.Drawing.Point(20, 20)
      Me.ButtonCarpetaOrigen.Name = "ButtonCarpetaOrigen"
      Me.ButtonCarpetaOrigen.Size = New System.Drawing.Size(98, 23)
      Me.ButtonCarpetaOrigen.TabIndex = 0
      Me.ButtonCarpetaOrigen.Text = "Carpeta origen"
      Me.ButtonCarpetaOrigen.UseVisualStyleBackColor = True
      '
      'ButtonCarpetaDestino
      '
      Me.ButtonCarpetaDestino.Location = New System.Drawing.Point(20, 64)
      Me.ButtonCarpetaDestino.Name = "ButtonCarpetaDestino"
      Me.ButtonCarpetaDestino.Size = New System.Drawing.Size(98, 23)
      Me.ButtonCarpetaDestino.TabIndex = 1
      Me.ButtonCarpetaDestino.Text = "Carpeta destino"
      Me.ButtonCarpetaDestino.UseVisualStyleBackColor = True
      '
      'TextBoxCarpetaOrigen
      '
      Me.TextBoxCarpetaOrigen.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.TextBoxCarpetaOrigen.BackColor = System.Drawing.SystemColors.WindowText
      Me.TextBoxCarpetaOrigen.ForeColor = System.Drawing.SystemColors.Window
      Me.TextBoxCarpetaOrigen.Location = New System.Drawing.Point(145, 22)
      Me.TextBoxCarpetaOrigen.Name = "TextBoxCarpetaOrigen"
      Me.TextBoxCarpetaOrigen.ReadOnly = True
      Me.TextBoxCarpetaOrigen.Size = New System.Drawing.Size(537, 20)
      Me.TextBoxCarpetaOrigen.TabIndex = 2
      '
      'TextBoxCarpetaDestino
      '
      Me.TextBoxCarpetaDestino.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
      Me.TextBoxCarpetaDestino.BackColor = System.Drawing.SystemColors.WindowText
      Me.TextBoxCarpetaDestino.ForeColor = System.Drawing.SystemColors.Window
      Me.TextBoxCarpetaDestino.Location = New System.Drawing.Point(145, 66)
      Me.TextBoxCarpetaDestino.Name = "TextBoxCarpetaDestino"
      Me.TextBoxCarpetaDestino.ReadOnly = True
      Me.TextBoxCarpetaDestino.Size = New System.Drawing.Size(537, 20)
      Me.TextBoxCarpetaDestino.TabIndex = 3
      '
      'frmPral
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.ClientSize = New System.Drawing.Size(733, 192)
      Me.Controls.Add(Me.GroupBoxBotones)
      Me.Controls.Add(Me.GroupBoxCarpetas)
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
      Me.Name = "frmPral"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "SynchronizeFLDR"
      Me.GroupBoxCarpetas.ResumeLayout(False)
      Me.GroupBoxCarpetas.PerformLayout()
      Me.GroupBoxBotones.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

   Friend WithEvents GroupBoxCarpetas As GroupBox
   Friend WithEvents GroupBoxBotones As GroupBox
   Friend WithEvents ButtonCarpetaDestino As Button
   Friend WithEvents ButtonCarpetaOrigen As Button
   Friend WithEvents ButtonAcercaDe As Button
   Friend WithEvents ButtonSincronizarCarpetas As Button
   Friend WithEvents ButtonSalir As Button
   Friend WithEvents TextBoxCarpetaDestino As TextBox
   Friend WithEvents TextBoxCarpetaOrigen As TextBox
End Class
