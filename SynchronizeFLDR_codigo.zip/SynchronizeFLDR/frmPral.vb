﻿Imports System.Windows.Forms.FolderBrowserDialog
Imports Microsoft.VisualBasic.FileIO
Imports System.IO          'Por algunas excepciones

Public Class frmPral
   Private Sub ButtonCarpetaOrigen_Click(sender As Object, e As EventArgs) Handles ButtonCarpetaOrigen.Click
      TextBoxCarpetaOrigen.Text = funRetornarCarpetaSeleccionda(ButtonCarpetaOrigen.Text)
   End Sub

   Private Sub ButtonCarpetaDestino_Click(sender As Object, e As EventArgs) Handles ButtonCarpetaDestino.Click
      TextBoxCarpetaDestino.Text = funRetornarCarpetaSeleccionda(ButtonCarpetaDestino.Text)
   End Sub

   Private Function funRetornarCarpetaSeleccionda(ByVal nombreCarpeta As String) As String
      'Creamos un objeto para seleccionar una carpeta en vez de un archivo
      Dim folderBrowserDialog1 As FolderBrowserDialog
      folderBrowserDialog1 = New FolderBrowserDialog

      'Ponemos una descripcion al cuadro de diálogo
      folderBrowserDialog1.Description = "Seleccione " & nombreCarpeta
      'Establecemos que no se pueden crear nuevas carpetas
      folderBrowserDialog1.ShowNewFolderButton = False
      'Establecemos la carpeta de origen, en este caso la carpeta raíz del equipo
      folderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer

      'Miramos a ver qué ha seleccionado el usurio...
      Dim resultado As DialogResult = folderBrowserDialog1.ShowDialog()
      '...si ha seleccionado ok en vez de cancelar se mira la carpeta seleccionada
      If resultado = DialogResult.OK Then
         Dim carpeta As String = folderBrowserDialog1.SelectedPath
         Return carpeta
      Else
         Return ""
      End If
   End Function

   Private Sub ButtonSalir_Click(sender As Object, e As EventArgs) Handles ButtonSalir.Click
      'Cerramos el formulario
      Me.Close()
   End Sub

   Private Sub ButtonAcercaDe_Click(sender As Object, e As EventArgs) Handles ButtonAcercaDe.Click
      Dim frmAcercaDe As AboutBoxAcercaDe = New AboutBoxAcercaDe
      frmAcercaDe.Show()
   End Sub

   Private Sub ButtonSincronizarCarpetas_Click(sender As Object, e As EventArgs) Handles ButtonSincronizarCarpetas.Click
      Dim mensaje As String
      If TextBoxCarpetaOrigen.Text = "" Or TextBoxCarpetaDestino.Text = "" Then
         mensaje = "Necesita indicar las carpetas de origen y destino"
      Else
         'Envolvemos a función que puede crear problemas en un bloque try Cath para tratar las excecpciones
         Try
            'Copia carpeta origen en destino
            My.Computer.FileSystem.CopyDirectory(TextBoxCarpetaOrigen.Text, TextBoxCarpetaDestino.Text,
                                                 FileIO.UIOption.AllDialogs, FileIO.UICancelOption.DoNothing)
            mensaje = "Proceso finalizado"
         Catch excepcion As ArgumentException
            mensaje = excepcion.Message
         End Try
      End If
      MessageBox.Show(mensaje, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
      Me.Focus()
   End Sub

End Class